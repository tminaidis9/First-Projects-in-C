
int shop(int** PinakasR,int m, int n, int* k, int** c);
int R(int** PinakasR,int* min,int i,int p,int m,int n, int* k, int** c);
int minimum(int num,int* min);